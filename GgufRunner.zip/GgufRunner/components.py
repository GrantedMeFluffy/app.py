import os
import time
import streamlit as st
from typing import Dict, Any, List, Optional
from model_manager import ModelManager
from session_handler import SessionHandler
from utils import format_message, calculate_file_size, format_model_params_display, get_prompt_template

def show_header() -> None:
    """Display the application header."""
    st.title("GGUF Model Chat")
    st.markdown("Upload, load, and chat with GGUF language models")

def show_sidebar(model_manager: ModelManager, session_handler: SessionHandler) -> None:
    """
    Display the sidebar with model loading options and settings.
    
    Args:
        model_manager: The ModelManager instance
        session_handler: The SessionHandler instance
    """
    st.title("Model Controls")
    
    # Option buttons
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Load Model", key="load_model_btn", use_container_width=True):
            st.session_state.show_session_browser = False
            st.rerun()
    
    with col2:
        if st.button("Browse Sessions", key="browse_sessions_btn", use_container_width=True):
            st.session_state.show_session_browser = True
            st.rerun()
    
    st.divider()
    
    # Model selection and loading
    available_models = model_manager.get_available_models()
    
    if available_models:
        st.subheader("Load Available Model")
        selected_model = st.selectbox(
            "Select a model to load", 
            options=available_models,
            format_func=os.path.basename
        )
        
        # Model parameters
        with st.expander("Model Parameters"):
            ctx_length = st.slider("Context Length (n_ctx)", 512, 8192, 2048, 512)
            batch_size = st.slider("Batch Size (n_batch)", 128, 1024, 512, 128)
            gpu_layers = st.slider("GPU Layers", 0, 100, 0, 1)
        
        # Load button
        if st.button("Load Selected Model", use_container_width=True):
            if selected_model:
                # Create progress bar for loading
                progress_text = "Loading model..."
                progress_bar = st.progress(0)
                
                # Parameters for model loading
                params = {
                    "n_ctx": ctx_length,
                    "n_batch": batch_size,
                    "n_gpu_layers": gpu_layers,
                }
                
                # Loading happens in stages for better UI feedback
                progress_bar.progress(0.1)
                time.sleep(0.5)  # Show progress starting
                
                # Load model
                success = model_manager.load_model(selected_model, params)
                
                progress_bar.progress(0.9)
                time.sleep(0.5)  # Small delay to show progress
                
                if success:
                    progress_bar.progress(1.0)
                    st.success(f"Model loaded successfully: {os.path.basename(selected_model)}")
                    # If there was a session loaded, check model compatibility
                    if "loaded_session_model_path" in st.session_state:
                        if st.session_state["loaded_session_model_path"] != selected_model:
                            st.warning("The loaded session was created with a different model. Results may vary.")
                    st.rerun()
                else:
                    progress_bar.empty()
                    st.error("Failed to load model")
    
    # Model unloading
    if st.session_state.get("model_loaded"):
        st.divider()
        st.subheader("Memory Management")
        if st.button("Unload Current Model", use_container_width=True):
            model_manager.unload_model()
            st.success("Model unloaded successfully")
            st.rerun()
    
    # Session management
    if st.session_state.get("model_loaded") and st.session_state.get("messages"):
        st.divider()
        st.subheader("Session Management")
        
        session_name = st.text_input("Session Name (optional)", 
                                   placeholder="Enter a name to save this session")
        
        if st.button("Save Current Session", use_container_width=True):
            saved_path = session_handler.save_session(session_name)
            st.success(f"Session saved: {os.path.basename(saved_path)}")
    
    # Add generation settings
    if st.session_state.get("model_loaded"):
        st.divider()
        st.subheader("Generation Settings")
        
        # Display generation parameters
        with st.expander("Generation Parameters", expanded=False):
            st.session_state["temperature"] = st.slider(
                "Temperature", 0.0, 2.0, 0.7, 0.1,
                help="Higher values produce more diverse outputs"
            )
            
            st.session_state["max_tokens"] = st.slider(
                "Max Tokens", 64, 4096, 512, 64,
                help="Maximum number of tokens to generate"
            )
            
            st.session_state["top_p"] = st.slider(
                "Top P", 0.0, 1.0, 0.95, 0.05,
                help="Nucleus sampling parameter"
            )
            
            st.session_state["top_k"] = st.slider(
                "Top K", 1, 100, 40, 1,
                help="Only sample from the top K most likely tokens"
            )
            
            st.session_state["repeat_penalty"] = st.slider(
                "Repetition Penalty", 1.0, 2.0, 1.1, 0.05,
                help="Penalty for repeating tokens"
            )
        
        # Roleplay mode controls
        st.divider()
        st.subheader("Roleplay Mode")
        
        # Toggle for roleplay mode
        st.session_state["roleplay_mode"] = st.toggle(
            "Enable Roleplay Mode", 
            st.session_state.get("roleplay_mode", False),
            help="Make the AI adopt different personas and behaviors"
        )
        
        # Persona selection (only shown when roleplay mode is enabled)
        if st.session_state.get("roleplay_mode", False):
            persona_options = {
                "helpful_assistant": "Helpful Assistant",
                "pirate": "Pirate",
                "shakespeare": "Shakespeare",
                "detective": "Detective",
                "sci_fi_robot": "Sci-Fi Robot",
                "medieval_scholar": "Medieval Scholar",
                "cosmic_entity": "Cosmic Entity"
            }
            
            st.session_state["selected_persona"] = st.selectbox(
                "Select Persona",
                options=list(persona_options.keys()),
                format_func=lambda x: persona_options[x],
                index=list(persona_options.keys()).index(
                    st.session_state.get("selected_persona", "helpful_assistant")
                ),
                help="Choose a persona for the AI to adopt"
            )
            
            # Show the current persona's description
            from utils import get_persona_instructions
            with st.expander("Persona Description", expanded=False):
                st.markdown(get_persona_instructions(st.session_state.get("selected_persona", "helpful_assistant")))

def show_model_info() -> None:
    """Display information about the currently loaded model."""
    if st.session_state.get("current_model_path"):
        model_path = st.session_state["current_model_path"]
        model_size = calculate_file_size(model_path)
        model_params = st.session_state.get("current_model_params", {})
        
        with st.expander("Model Information", expanded=False):
            st.text(f"Model: {os.path.basename(model_path)}")
            st.text(f"Size: {model_size}")
            st.text(f"Load Time: {st.session_state.get('model_load_time', 0):.2f} seconds")
            st.text(f"Parameters: {format_model_params_display(model_params)}")

def show_chat_interface(model_manager: ModelManager, session_handler: SessionHandler) -> None:
    """
    Display the chat interface for interacting with the model.
    
    Args:
        model_manager: The ModelManager instance
        session_handler: The SessionHandler instance
    """
    # Show roleplay mode indicator if active
    if st.session_state.get("roleplay_mode", False):
        persona_options = {
            "helpful_assistant": "Helpful Assistant",
            "pirate": "Pirate",
            "shakespeare": "Shakespeare",
            "detective": "Detective",
            "sci_fi_robot": "Sci-Fi Robot",
            "medieval_scholar": "Medieval Scholar",
            "cosmic_entity": "Cosmic Entity"
        }
        
        selected_persona = st.session_state.get("selected_persona", "helpful_assistant")
        persona_display_name = persona_options.get(selected_persona, "Unknown Persona")
        
        st.info(f"🎭 Roleplay Mode Active: **{persona_display_name}**")
    
    # Display chat messages from history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Input area for new message
    if prompt := st.chat_input("Type your message here..."):
        # Add user message to chat history
        st.session_state.messages.append(format_message("user", prompt))
        
        # Display user message in chat interface
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Generate and display assistant response
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            full_response = ""
            
            # Get generation parameters from session state
            generation_params = {
                "max_tokens": st.session_state.get("max_tokens", 512),
                "temperature": st.session_state.get("temperature", 0.7),
                "top_p": st.session_state.get("top_p", 0.95),
                "top_k": st.session_state.get("top_k", 40),
                "repeat_penalty": st.session_state.get("repeat_penalty", 1.1),
            }
            
            # Create the full prompt from message history, with roleplay mode if enabled
            full_prompt = get_prompt_template(
                st.session_state.messages,
                roleplay_mode=st.session_state.get("roleplay_mode", False),
                persona=st.session_state.get("selected_persona", "helpful_assistant")
            )
            
            # Add a stop button with better styling
            col1, col2 = st.columns([3, 1])
            with col2:
                stop_button = st.button(
                    "🛑 Stop Generation", 
                    key="stop_generation",
                    help="Click to stop the AI from generating more text",
                    use_container_width=True
                )
            
            # Reset the stopped flag for new generation
            st.session_state["generation_stopped"] = False
            
            # Stream the response
            generating = True
            try:
                for response_chunk in model_manager.generate_response(
                    full_prompt, 
                    generation_params=generation_params,
                    stream=True
                ):
                    # Check if stop button was clicked
                    if stop_button or st.session_state.get("generation_stopped", False):
                        st.session_state["generation_stopped"] = True
                        message_placeholder.markdown(full_response + " *(generation stopped)*")
                        generating = False
                        break
                    
                    full_response = response_chunk
                    message_placeholder.markdown(full_response + "▌")
            except Exception as e:
                st.error(f"Error during generation: {str(e)}")
                generating = False
                
            # Only display the final response if generation completed normally
            if generating:
                message_placeholder.markdown(full_response)
        
        # Add assistant response to chat history
        st.session_state.messages.append(format_message("assistant", full_response))

def show_upload_section(model_manager: ModelManager) -> None:
    """
    Display the model upload section.
    
    Args:
        model_manager: The ModelManager instance
    """
    st.header("Upload New Model")
    
    with st.expander("Upload GGUF Model", expanded=True):
        # Model file upload
        uploaded_file = st.file_uploader(
            "Upload GGUF model file (up to 10GB)",
            type=["gguf"],
            help="Upload a GGUF (GPT-Generated Unified Format) language model file. Maximum file size is 10GB."
        )
        
        # Optional custom name
        custom_name = st.text_input(
            "Custom model name (optional)",
            placeholder="Enter a name for your model"
        )
        
        # Upload button
        if uploaded_file is not None:
            if st.button("Process Upload", use_container_width=True):
                save_path = model_manager.upload_model(uploaded_file, custom_name)
                if save_path:
                    st.success(f"Model saved as {os.path.basename(save_path)}")
                    
                    # Ask if user wants to load the model
                    if st.button("Load Uploaded Model Now", use_container_width=True):
                        # Default parameters for model loading
                        params = {
                            "n_ctx": 2048,
                            "n_batch": 512,
                            "n_gpu_layers": 0,
                        }
                        success = model_manager.load_model(save_path, params)
                        if success:
                            st.success(f"Model loaded successfully: {os.path.basename(save_path)}")
                            st.rerun()
                        else:
                            st.error("Failed to load model")
                else:
                    st.error("Failed to save model")

def show_session_browser(session_handler: SessionHandler, model_manager: ModelManager) -> None:
    """
    Display the session browser for loading previous sessions.
    
    Args:
        session_handler: The SessionHandler instance
        model_manager: The ModelManager instance
    """
    if st.session_state.get("show_session_browser") or not st.session_state.get("model_loaded"):
        st.header("Session Browser")
        
        # Get available sessions
        available_sessions = session_handler.get_available_sessions()
        
        if not available_sessions:
            st.info("No saved sessions found. Start a new conversation and save it to see it here.")
            return
        
        # Display sessions in a table with actions
        for idx, session in enumerate(available_sessions):
            with st.expander(f"{session['name']} - {session['formatted_time']}"):
                st.text(f"Messages: {session['message_count']}")
                st.text(f"Model: {os.path.basename(session['model_path'])}")
                
                # Display roleplay information if enabled
                if session.get('roleplay_mode', False):
                    persona_options = {
                        "helpful_assistant": "Helpful Assistant",
                        "pirate": "Pirate",
                        "shakespeare": "Shakespeare",
                        "detective": "Detective",
                        "sci_fi_robot": "Sci-Fi Robot",
                        "medieval_scholar": "Medieval Scholar",
                        "cosmic_entity": "Cosmic Entity"
                    }
                    persona = persona_options.get(session.get('selected_persona', 'helpful_assistant'), 'Unknown Persona')
                    st.text(f"Roleplay Mode: Enabled - {persona}")
                
                st.text(f"Preview: {session['preview']}")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("Load Session", key=f"load_{idx}", use_container_width=True):
                        session_data = session_handler.load_session(session['file_path'])
                        if session_data:
                            # Apply the session to the current state
                            success = session_handler.apply_session(session_data)
                            if success:
                                st.success("Session loaded successfully!")
                                
                                # Check if we need to load the corresponding model
                                if session_data.get("model_path") and os.path.exists(session_data["model_path"]):
                                    if (not st.session_state.get("model_loaded") or 
                                        st.session_state.get("current_model_path") != session_data["model_path"]):
                                        st.info(f"This session uses model: {os.path.basename(session_data['model_path'])}")
                                        if st.button("Load Required Model", key=f"load_model_{idx}", use_container_width=True):
                                            success = model_manager.load_model(
                                                session_data["model_path"], 
                                                session_data.get("model_params", {})
                                            )
                                            if success:
                                                st.success("Model loaded successfully!")
                                                st.session_state.show_session_browser = False
                                                st.rerun()
                                            else:
                                                st.error("Failed to load the model for this session")
                                else:
                                    st.session_state.show_session_browser = False
                                    st.rerun()
                            else:
                                st.error("Failed to apply session")
                        else:
                            st.error("Failed to load session data")
                
                with col2:
                    if st.button("Delete Session", key=f"delete_{idx}", use_container_width=True):
                        success = session_handler.delete_session(session['file_path'])
                        if success:
                            st.success("Session deleted successfully!")
                            st.rerun()
                        else:
                            st.error("Failed to delete session")
