import os
import time
import streamlit as st
from model_manager import ModelManager
from session_handler import SessionHandler
from components import (
    show_header, 
    show_sidebar, 
    show_chat_interface, 
    show_model_info,
    show_upload_section,
    show_session_browser
)
from utils import initialize_session_state

# Set page configuration
st.set_page_config(
    page_title="GGUF Model Chat",
    page_icon="💬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize or get session state variables
initialize_session_state()

# Initialize model manager and session handler
model_manager = ModelManager()
session_handler = SessionHandler()

# App Layout
show_header()

# Sidebar for model loading/settings
with st.sidebar:
    show_sidebar(model_manager, session_handler)

# Main area
if st.session_state.get("current_model_path") and st.session_state.get("model_loaded"):
    # Display current model info
    show_model_info()
    
    # Show chat interface
    show_chat_interface(model_manager, session_handler)
    
elif st.session_state.get("show_session_browser"):
    # Display session browser
    show_session_browser(session_handler, model_manager)
    
else:
    # Model upload section when no model is loaded
    show_upload_section(model_manager)
    
    # Also show recent sessions section
    show_session_browser(session_handler, model_manager)

# Create models and sessions directories if they don't exist
os.makedirs("models", exist_ok=True)
os.makedirs("sessions", exist_ok=True)
