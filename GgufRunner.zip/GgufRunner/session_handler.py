import os
import json
import time
import datetime
from typing import Optional, Dict, Any, List
import streamlit as st

class SessionHandler:
    """Class to handle chat session saving and loading."""
    
    def __init__(self, sessions_dir: str = "sessions"):
        self.sessions_dir = sessions_dir
        # Create the sessions directory if it doesn't exist
        os.makedirs(self.sessions_dir, exist_ok=True)
    
    def save_session(self, name: Optional[str] = None) -> str:
        """
        Save the current chat session to a file.
        
        Args:
            name: Optional custom name for the session
            
        Returns:
            str: Path to the saved session file
        """
        # Create timestamp for filename if no name is provided
        if not name:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            name = f"Session_{timestamp}"
        
        # Make sure the filename is valid for Windows
        name = name.replace(" ", "_").replace("/", "_").replace("\\", "_")
        name = name.replace(":", "_").replace("?", "_").replace("*", "_")
        name = name.replace('"', "_").replace("<", "_").replace(">", "_").replace("|", "_")
        
        if not name.endswith(".json"):
            name = f"{name}.json"
        
        # Create session data
        session_data = {
            "timestamp": time.time(),
            "formatted_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "model_path": st.session_state.get("current_model_path", ""),
            "model_params": st.session_state.get("current_model_params", {}),
            "messages": st.session_state.get("messages", []),
            "roleplay_mode": st.session_state.get("roleplay_mode", False),
            "selected_persona": st.session_state.get("selected_persona", "helpful_assistant"),
            "metadata": {
                "name": name,
                "session_id": st.session_state.get("session_id", "")
            }
        }
        
        # Save to file
        file_path = os.path.join(self.sessions_dir, name)
        with open(file_path, "w") as f:
            json.dump(session_data, f, indent=2)
        
        return file_path
    
    def load_session(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Load a chat session from a file.
        
        Args:
            file_path: Path to the session file to load
            
        Returns:
            Dict: The loaded session data
        """
        if not os.path.exists(file_path):
            st.error(f"Session file not found: {file_path}")
            return None
        
        try:
            with open(file_path, "r") as f:
                session_data = json.load(f)
            
            return session_data
        except Exception as e:
            st.error(f"Error loading session: {str(e)}")
            return None
    
    def apply_session(self, session_data: Dict[str, Any]) -> bool:
        """
        Apply a loaded session to the current Streamlit session state.
        
        Args:
            session_data: The session data to apply
            
        Returns:
            bool: Whether the session was applied successfully
        """
        if not session_data:
            return False
        
        try:
            # Update the session state with the loaded messages
            st.session_state["messages"] = session_data.get("messages", [])
            
            # Store model information for potential loading
            st.session_state["loaded_session_model_path"] = session_data.get("model_path", "")
            st.session_state["loaded_session_model_params"] = session_data.get("model_params", {})
            
            # Load roleplay mode settings if available
            if "roleplay_mode" in session_data:
                st.session_state["roleplay_mode"] = session_data.get("roleplay_mode", False)
            
            if "selected_persona" in session_data:
                st.session_state["selected_persona"] = session_data.get("selected_persona", "helpful_assistant")
            
            return True
        except Exception as e:
            st.error(f"Error applying session: {str(e)}")
            return False
    
    def get_available_sessions(self) -> List[Dict[str, Any]]:
        """
        Get a list of available session files with basic metadata.
        
        Returns:
            List[Dict]: List of session info dictionaries
        """
        # Create sessions directory if it doesn't exist
        os.makedirs(self.sessions_dir, exist_ok=True)
        
        # Get all .json files in the sessions directory
        session_files = [
            os.path.join(self.sessions_dir, f) for f in os.listdir(self.sessions_dir) 
            if f.endswith(".json")
        ]
        
        # Read basic metadata
        sessions_info = []
        for file_path in session_files:
            try:
                with open(file_path, "r") as f:
                    data = json.load(f)
                
                # Extract basic info
                session_info = {
                    "file_path": file_path,
                    "name": os.path.basename(file_path),
                    "timestamp": data.get("timestamp", 0),
                    "formatted_time": data.get("formatted_time", "Unknown"),
                    "model_path": data.get("model_path", "Unknown"),
                    "message_count": len(data.get("messages", [])),
                    "roleplay_mode": data.get("roleplay_mode", False),
                    "selected_persona": data.get("selected_persona", "helpful_assistant"),
                    "preview": self._generate_preview(data.get("messages", []))
                }
                sessions_info.append(session_info)
            except Exception as e:
                # Skip files with errors
                continue
        
        # Sort by timestamp (newest first)
        sessions_info.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return sessions_info
    
    def _generate_preview(self, messages: List[Dict[str, str]], max_length: int = 100) -> str:
        """
        Generate a short preview of the conversation.
        
        Args:
            messages: List of message dictionaries
            max_length: Maximum length of the preview
            
        Returns:
            str: Short preview of the conversation
        """
        if not messages:
            return "Empty conversation"
        
        # Get the first few exchanges
        preview_messages = messages[:min(4, len(messages))]
        
        # Format the preview
        preview = " | ".join([f"{msg['role']}: {msg['content'][:30]}..." for msg in preview_messages])
        
        # Truncate if too long
        if len(preview) > max_length:
            preview = preview[:max_length] + "..."
        
        return preview
    
    def delete_session(self, file_path: str) -> bool:
        """
        Delete a session file.
        
        Args:
            file_path: Path to the session file to delete
            
        Returns:
            bool: Whether the file was deleted successfully
        """
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                return True
            return False
        except Exception as e:
            st.error(f"Error deleting session: {str(e)}")
            return False
